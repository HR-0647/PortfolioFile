﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DataSet : MonoBehaviour
{
    [SerializeField] private DeckData Deck;
    [SerializeField] private TrapData[] Trap;
    [SerializeField] private Image[] TrapSprite;
    [SerializeField] private int Deckint;

    public void Start()
    {
        SpriteChange();
    }

    public DeckData GetDeck()
    {
        return ScriptableObject.Instantiate(Deck);
    }

    public void DeckSet(DeckData Deck)
    {
        this.Deck = Deck;
    }

    public void TrapSet(TrapData[] trapData)
    {
        this.Trap = trapData;
    }

    public void SpriteChange()
    {
        for (int i = 0; i < Deckint; i++) {
            TrapSprite[i].sprite = Trap[i].CardSprite;
        }
    }
}
