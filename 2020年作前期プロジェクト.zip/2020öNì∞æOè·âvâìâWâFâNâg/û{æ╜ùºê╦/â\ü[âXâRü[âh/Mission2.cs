﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;

public class Mission2 : MonoBehaviour
{
    //インスペクターで取得
    [SerializeField, Header("- シーン遷移先名")]
    private string sceneLoadName;
    [SerializeField] UnityEngine.UI.Text textbox;
    [SerializeField] UnityEngine.UI.Text textbox2;
    [SerializeField] SpriteRenderer body, face;
    [SerializeField] SpriteRenderer body2, face2;
    [SerializeField] SpriteRenderer body3, face3;
    [SerializeField] SpriteRenderer Emote1, Emote2, Emote3;
    [SerializeField] SpriteAtlas atlas;
    [SerializeField] SpriteAtlas atlas2;
    [SerializeField] SpriteAtlas atlas3;
    [SerializeField] SpriteAtlas Emote; //エモートアイコン
    [SerializeField] AudioSource wolf;
    [SerializeField] AudioSource SinarioSE;
    [SerializeField]
    [Range(0.001f, 0.3f)]
    float intervalForCharacterDisplay = 0.05f; //1文字にかかる時間
    [SerializeField]
    private GameObject PressButton;

    [Header("フェード")] public FadeImage fade;

    // イメージを白黒に設定
    [SerializeField] Color btnColor1 = Color.white;
    [SerializeField] Color btnColor2 = Color.black;
    [SerializeField] Image image;
    [SerializeField] Image image2;
    [SerializeField] GameObject PressText;

    private bool firstPush = false;
    private bool goNextScene = false;
    private int currentLine = 0; //行番号
    private string cureentText = string.Empty; //文字列
    private float timeUntilDisplay = 0; //表示にかかる時間
    private float timeElapsed = 1; //文字列の表示を開始した時間
    private int lastUpdateCharecter = -1; //表示中の文字数
    public string[] scenarios; //シナリオ格納
    private bool beruSpeak = false;
    private bool adamuSpeak = false;
    private bool usagiSpeak = false;

    bool btnChangeFlag = true;

    private void Update()
    {
        StartCoroutine(Button());
        StartCoroutine(SinarioPressButton());

        if (currentLine < scenarios.Length && (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2")))
        {
            SetNextLine();
        }

        //クリックから経過した時間が想定表示時間のなん%を確認し、表示文字数を出す
        int displayCharacterCount = (int)(Mathf.Clamp01((Time.time - timeElapsed) / timeUntilDisplay) * cureentText.Length);

        //表示文字数が前回の表示文字数と異なるテキストを更新する
        if (displayCharacterCount != lastUpdateCharecter)
        {
            textbox.text = cureentText.Substring(0, displayCharacterCount);
            lastUpdateCharecter = displayCharacterCount;
        }

        if (Input.GetButtonDown("Fire_Options"))
        {
            SceneManager.LoadScene(sceneLoadName);
        }
    }

    //コルーチンからテキスト、話しているキャラを白黒させる、表情差分
    private IEnumerator Start()
    {
        SetNextLine();
        yield return null;
        currentLine = 1;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_驚き");
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        Emote2.sprite = Emote.GetSprite("！");
        adamuSpeak = false;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 2;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_驚き");
        Emote2.enabled = false;
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 3;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_悲しみ");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 4;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 5;
        textbox2.text = "狼の群れ";
        wolf.Play();
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 6;
        textbox2.text = "アダム";
        SinarioSE.Play();
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_怒り");
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 7;
        textbox2.text = "ベル";
        SinarioSE.Play();
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_驚き");
        adamuSpeak = false;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 8;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 9;
        textbox2.text = "ベル";
        SinarioSE.Play();
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_怒り");
        adamuSpeak = false;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 10;
        textbox2.text = "";
        PressText.SetActive(true);
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
    }

    private IEnumerator Button()
    {
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        Debug.Log("Press Start!");
        if (!firstPush)
        {
            Debug.Log("Go Next Scene!");
            fade.StartFadeOut();
            firstPush = true;
        }
        if (!goNextScene && fade.IsFadeOutComplete())
        {
            SceneManager.LoadScene(sceneLoadName);
            goNextScene = true;
        }
    }

    //画像を白黒変える
    public void OnClick1() // アダムを白黒にする
    {
        if (beruSpeak == true)
        {
            image.color = btnColor2;
            face.color = btnColor2;
        }
        else if (beruSpeak == false)
        {
            image.color = btnColor1;
            face.color = btnColor1;
        }
    }

    public void OnClick2() // ベルを白黒にする
    {
        if (adamuSpeak == true)
        {
            image2.color = btnColor2;
            face2.color = btnColor2;
        }
        else if (adamuSpeak == false)
        {
            image2.color = btnColor1;
            face2.color = btnColor1;
        }
    }

    private void OnClick3()
    {
        if (usagiSpeak == true)
        {
            body3.color = btnColor2;
            face3.color = btnColor2;
        }
        else if (usagiSpeak == false)
        {
            body3.color = btnColor1;
            face3.color = btnColor1;
        }
    }

    void SetNextLine()
    {
        cureentText = scenarios[currentLine];
        currentLine++;

        //想定表示時間と現在の時刻をキャッシュ
        timeUntilDisplay = cureentText.Length * intervalForCharacterDisplay;
        timeElapsed = Time.time;

        //文字カウントを初期化
        lastUpdateCharecter = -1;
    }
    public void SkipScene()
    {
        SceneManager.LoadScene(sceneLoadName);
    }

    public IEnumerator SinarioPressButton()
    {
        if (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"))
        {
            yield return new WaitForSeconds(intervalForCharacterDisplay);
            PressButton.SetActive(false);
            yield return new WaitForSeconds(timeUntilDisplay);
            PressButton.SetActive(true);
        }
    }
}
