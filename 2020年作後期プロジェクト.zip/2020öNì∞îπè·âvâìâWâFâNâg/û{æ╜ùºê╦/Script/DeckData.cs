﻿using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Detas/DeckData",fileName = "DeckData")]
public class DeckData : ScriptableObject
{
    [SerializeField] TrapData[] DeckID;

    public TrapData[] deckid
    {
        get => DeckID;
#if UNITY_EDITOR
        set => DeckID = value;
#endif
    }

    //public DeckData Copy()
    //{

    //    DeckData result = new DeckData();
    //    result.deckid = deckid;

    //    return result;
    //}
}