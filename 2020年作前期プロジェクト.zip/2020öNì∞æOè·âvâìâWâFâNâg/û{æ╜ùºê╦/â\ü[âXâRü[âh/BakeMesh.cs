﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BakeMesh : MonoBehaviour
{
    [SerializeField]
    private GameObject players;

    [SerializeField]
    SkinnedMeshRenderer BaseMeshObj;    // ベイクする元のオブジェクト

    [SerializeField]
    GameObject BakeMeshObj;            // ベイクしたメッシュを格納するGameObject
    private PlayerController playerController;

    public bool flag = true;
    public bool Front;

    // BakeMeshObjをインスタンスした際のSkinnedMeshRendererリスト
    List<SkinnedMeshRenderer> BakeCloneMeshList;

    public  int CloneCount = 4;       // 残像数
    public  int FlameCountMax = 4;    // 残像を更新する頻度
    int FlameCount = 0;

    void Start()
    {
        BakeCloneMeshList = new List<SkinnedMeshRenderer>();
        players = GameObject.FindGameObjectWithTag("Player");
        playerController = players.GetComponent<PlayerController>();
        
        // 残像を複製
        for (int i = 0; i < CloneCount; i++)
        {
            var obj = Instantiate(BakeMeshObj, new Vector3(0, -10, 0), Quaternion.Euler(0,-180,0));
            BakeCloneMeshList.Add(obj.GetComponent<SkinnedMeshRenderer>());
        
        }
    }

    void FixedUpdate()
    {
        // 4フレームに一度更新
        FlameCount++;
        if (FlameCount % FlameCountMax != 0)
        {
            return;
        }

        // BakeしたMeshを１つ前にずらしていく
        for (int i = BakeCloneMeshList.Count - 1; i >= 1; i--)
        {
            BakeCloneMeshList[i].sharedMesh = BakeCloneMeshList[i - 1].sharedMesh;

            // 位置と回転をコピー
            BakeCloneMeshList[i].transform.position = BakeCloneMeshList[i - 1].transform.position;
            BakeCloneMeshList[i].transform.rotation = BakeCloneMeshList[i - 1].transform.rotation;
            if (playerController.isFront == true)
            {
                BakeCloneMeshList[0].transform.rotation = Quaternion.Euler(0, -180, 0);
            }
            if (playerController.isFront == false)
            {
                BakeCloneMeshList[0].transform.rotation = Quaternion.Euler(0, 0, 0);
            }
        }
        
        // 今のスキンメッシュをBakeする
        // ボトルネックになりやすいから注意！
        Mesh mesh = new Mesh();
        BaseMeshObj.BakeMesh(mesh);
        BakeCloneMeshList[0].sharedMesh = mesh;

        // 位置と回転をコピー
        BakeCloneMeshList[0].transform.position = transform.position;
        //BakeCloneMeshList[0].transform.rotation = transform.rotation;
    }
}