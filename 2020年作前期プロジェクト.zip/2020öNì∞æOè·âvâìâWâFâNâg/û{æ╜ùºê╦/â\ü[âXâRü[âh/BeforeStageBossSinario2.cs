﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;

public class BeforeStageBossSinario2 : MonoBehaviour
{
    //インスペクターで取得
    [SerializeField, Header("- シーン遷移先名")]
    private string sceneLoadName;
    [SerializeField] private UnityEngine.UI.Text textbox; //文章
    [SerializeField] private UnityEngine.UI.Text textbox2; //名前
    [SerializeField] private SpriteRenderer body, face; //野獣の表情差分
    [SerializeField] private SpriteRenderer body2, face2; //美女の表情差分
    [SerializeField] private SpriteRenderer body3, face3; //ウサギの表情
    [SerializeField] private SpriteRenderer body4, face4; //タヌキの表情
    [SerializeField] private SpriteRenderer Emote1, Emote2;
    [SerializeField] private SpriteRenderer Emote3;
    [SerializeField] private SpriteRenderer Emote4;
    [SerializeField] private SpriteAtlas atlas; //野獣の表情差分のパーツ
    [SerializeField] private SpriteAtlas atlas2; //美女の表情差分のパーツ
    [SerializeField] private SpriteAtlas atlas3;
    [SerializeField] private SpriteAtlas atlas4;
    [SerializeField] private SpriteAtlas Emote; //エモートアイコン
    [SerializeField] private SpriteAtlas Emote02;
    [SerializeField] private ParticleSystem Moya1;
    [SerializeField] private GameObject Fade;
    [SerializeField] private GameObject ImageOn;
    [SerializeField] private AudioSource SinarioSE;
    [SerializeField] private AudioSource BGM1;
    [SerializeField] private AudioSource BGM2;
    [SerializeField] private GameObject FadeImage2;
    [SerializeField] private ParticleSystem Zangeki1;
    //[SerializeFieldprivate ] SpriteAtlas Emote122;
    //[SerializeField] SpriteAtlas Emote133;
    [SerializeField]
    [Range(0.001f, 0.3f)]
    float intervalForCharacterDisplay = 0.05f; //1文字にかかる時間
    [SerializeField]
    private GameObject PressButton;

    // イメージを白黒に設定
    [SerializeField] Color btnColor1 = Color.white; //カラー選択（白と書いてありますがインスペクターで変更可能）
    [SerializeField] Color btnColor2 = Color.black;
    // 立ち絵
    [SerializeField] Image image;
    [SerializeField] Image image2;
    [SerializeField] Image image3;
    [SerializeField] Image image4;
    [SerializeField] GameObject PressText;
    [SerializeField] GameObject Rock1;
    [SerializeField] GameObject Rock2;
 
    [Header("フェード")] public FadeImage fade;

    private bool firstPush = false;
    private bool goNextScene = false;
    private int currentLine = 0; //行番号
    private string cureentText = string.Empty; //文字列
    private float timeUntilDisplay = 0; //表示にかかる時間
    private float timeElapsed = 1; //文字列の表示を開始した時間
    private int lastUpdateCharecter = -1; //表示中の文字数
    public string[] scenarios; //シナリオ格納
    private bool beruSpeak = false;
    private bool adamuSpeak = false;
    private bool tanukiSpeak = false;
    private bool usagiSpeak = false;
    private bool ButtonDestroy = false;
    private Animator Flashimage;
    private Animator Fadeimage2;
    private bool isFlash;
    private bool OneClick = true;
    private bool CorutinSelect1 = false;
    private bool Flag1 = false;

    private void AnimatorSet()
    {
        Flashimage.SetBool("FlashImage", isFlash);
    }

    private void Awake()
    {
        Flashimage = Fade.GetComponent<Animator>();
        Fadeimage2 = FadeImage2.GetComponent<Animator>();
    }

    private void Start()
    {
        StartCoroutine(Sinario());
        StartCoroutine(Button());
    }

    private void Update()
    {
        if (currentLine < scenarios.Length && (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2")))
        {
            SetNextLine();
        }

        StartCoroutine(SinarioPressButton());

        //クリックから経過した時間が想定表示時間のなん%を確認し、表示文字数を出す
        int displayCharacterCount = (int)(Mathf.Clamp01((Time.time - timeElapsed) / timeUntilDisplay) * cureentText.Length);

        //表示文字数が前回の表示文字数と異なるテキストを更新する
        if (displayCharacterCount != lastUpdateCharecter)
        {
            textbox.text = cureentText.Substring(0, displayCharacterCount);
            lastUpdateCharecter = displayCharacterCount;
        }

        if (CorutinSelect1 == true)
        {
            StopCoroutine(Sinario());
        }

        if (Input.GetButtonDown("Fire_Options"))
        {
            SceneManager.LoadScene(sceneLoadName);
        }
    }

    //コルーチンからテキスト、話しているキャラを白黒させる、表情差分
    private IEnumerator Sinario()
    {
        SetNextLine();
        yield return null;

        currentLine = 1;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_怒り");
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 2;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 　笑顔");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 3;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 怒り2");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 4;
        textbox2.text = "";
        Zangeki1.Play();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 5;
        textbox2.text = "アダム";
        Rock1.SetActive(false);
        Rock2.SetActive(true);
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_笑顔");
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 6;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_ちょぴ怒り");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 7;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 8;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_笑顔");
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 9;
        textbox2.text = "";
        image4.enabled = false;
        Rock2.SetActive(false);
        FadeImage2.SetActive(true);
        BGM1.Stop();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 10;
        textbox2.text = "アダム";
        Fadeimage2.Play("FadeEndanim");
        face4.transform.position = new Vector3(0.9f, -1.7f, 0);
        face4.transform.rotation = new Quaternion(0, 180, 0, 0);
        BGM2.Play();
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_驚き");
        Emote1.sprite = Emote.GetSprite("！");
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 11;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki　怒り");
        SinarioSE.Play();
        Emote1.enabled = false;
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 12;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_驚き");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 13;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki　怒り");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 14;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 15;
        textbox2.text = "";
        Fade.SetActive(true);
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 16;
        textbox2.text = "ベル";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 怒り2");
        Emote4.sprite = Emote02.GetSprite("！？");
        SinarioSE.Play();
        Flashimage.Play("FadeEnd");
        ImageOn.SetActive(true);
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 17;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        Emote4.enabled = false;
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 18;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        tanukiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 19;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_驚き");
        SinarioSE.Play();
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 20;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 怒り2");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 21;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_怒り");
        Emote2.sprite = Emote.GetSprite("！");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 22;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_怒り");
        SinarioSE.Play();
        Emote2.enabled = false;
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 23;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 怒り2");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 24;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 25;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        tanukiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        currentLine = 26;
        textbox2.text = "";
        PressText.SetActive(true);
        yield return null;
    }

    private IEnumerator Button()
    {
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        if (!firstPush)
        {
            fade.StartFadeOut();
            firstPush = true;
        }
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        if (!goNextScene /*&& fade.IsFadeOutComplete()*/)
        {
            SceneManager.LoadScene(sceneLoadName);
            goNextScene = true;
        }
    }

    //画像を白黒変える
    private void OnClick1() // アダムを白黒にする
    {
        if (beruSpeak == true)
        {
            body.color = btnColor2;
            face.color = btnColor2;
            image.color = btnColor2;
        }
        else if (beruSpeak == false)
        {
            body.color = btnColor1;
            face.color = btnColor1;
            image.color = btnColor1;
        }
    }

    private void OnClick2() // ベルを白黒にする
    {
        if (adamuSpeak == true)
        {
            body2.color = btnColor2;
            face2.color = btnColor2;
            image2.color = btnColor2;
        }
        else if (adamuSpeak == false)
        {
            body2.color = btnColor1;
            face2.color = btnColor1;
            image2.color = btnColor1;
        }
    }

    private void OnClick3()
    {
        if (usagiSpeak == true)
        {
            body3.color = btnColor2;
            face3.color = btnColor2;
        }
        else if (usagiSpeak == false)
        {
            body3.color = btnColor1;
            face3.color = btnColor1;
        }
    }

    private void OnClick4()
    {
        if (tanukiSpeak == true)
        {
            body4.color = btnColor2;
            face4.color = btnColor2;
        }
        else if (tanukiSpeak == false)
        {
            body4.color = btnColor1;
            face4.color = btnColor1;
        }
    }

    void SetNextLine()
    {
        cureentText = scenarios[currentLine];
        currentLine++;

        //想定表示時間と現在の時刻をキャッシュ
        timeUntilDisplay = cureentText.Length * intervalForCharacterDisplay;
        timeElapsed = Time.time;

        //文字カウントを初期化
        lastUpdateCharecter = -1;
    }

    public void SkipSene()
    {
        SceneManager.LoadScene(sceneLoadName);
    }

    public IEnumerator SinarioPressButton()
    {
        if (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"))
        {
            yield return new WaitForSeconds(intervalForCharacterDisplay);
            PressButton.SetActive(false);
            yield return new WaitForSeconds(timeUntilDisplay);
            PressButton.SetActive(true);
        }
    }
}
