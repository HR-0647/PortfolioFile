﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SkillManager2 : MonoBehaviour
{
    private enum _PLAYER_TYPE
    {
        GIRL,
        BEAST,
        LENGTH
    }

    #region//インスペクターで取得
    [SerializeField]
    private GameObject players;
    [SerializeField]
    public GameObject Enemy;
    [SerializeField]
    private Animator beastAnimetor;
    [SerializeField]
    public BoxCollider2D sword;
    [SerializeField]
    public GameObject HitSword;
    [SerializeField]
    private ParticleSystem ZANGEKI;
    //[SerializeField]
    //public float ComboTime;
    //[SerializeField]
    //public float RemComboTime;
    //[SerializeField]
    //public int ComboLevel;
    //[SerializeField]
    //public int MaxComboLevel = 3;
    [SerializeField]
    private int hitHealMp;
    [SerializeField]
    private float attackKnockBackPower = 90;
    [SerializeField, Header("斬撃のクールタイム")]
    private float zangekiCoolTime;
    #endregion

    #region//ソード関連
    [SerializeField, Header("- ソードの攻撃力")]
    public int normalSwordAttakPoint = 15;
    #endregion

    #region
    private PlayerController playercontrller;
    private float vector = 0;
    #endregion

    public float remainCoolTime;

    // Start is called before the first frame update
    void Start()
    {
        playercontrller = players.GetComponent<PlayerController>();
        //sword = sword.GetComponent<BoxCollider2D>();
        players = GameObject.FindGameObjectWithTag("Player");
        GameObject.FindWithTag("Player").GetComponent<Collider2D>();
        sword.enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        remainCoolTime -= Time.deltaTime;

        // L3スティックをどちらの向きに倒しているか
        float axis = Input.GetAxis("Horizontal_L3");

        // 左右移動
        if (Input.GetKey(KeyCode.A) || axis < 0)
        {
            vector = -1;
        }
        if (Input.GetKey(KeyCode.D) || axis > 0)
        {
            vector = 1;
        }

        if ((Input.GetKeyDown(KeyCode.E) || Input.GetButtonDown("Fire_2")) && remainCoolTime < 0)
        {
            if (playercontrller.AttackSword)
            {
                remainCoolTime = zangekiCoolTime;
                beastAnimetor.SetTrigger("attackTrigger");
                if (!playercontrller.isdef)
                {
                    ParticleSystem obj = Instantiate(ZANGEKI, this.transform.position, Quaternion.identity);
                    obj.transform.localScale = new Vector3(transform.localScale.x * vector, transform.localScale.y, transform.localScale.z);

                    //if (ComboLevel == MaxComboLevel)
                    //{
                    //    RemComboTime = ComboTime;
                    //    ComboLevel = 0;
                    //}
                    //else
                    //{
                    //    ComboLevel++;
                    //}
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            GameObject obj2 = Instantiate(HitSword,collision.transform.position,Quaternion.identity);
            obj2.transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y, transform.localScale.z);
            Rigidbody2D colRigidBody = collision.GetComponent<Rigidbody2D>();

            if (colRigidBody == null) return;

            colRigidBody.AddForce(transform.right * 400 * PlayerController.boolTypeToInt(playercontrller.isFront));
        }
    }
}