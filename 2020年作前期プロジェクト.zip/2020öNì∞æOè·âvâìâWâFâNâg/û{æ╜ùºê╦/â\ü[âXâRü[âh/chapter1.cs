﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class chapter1 : MonoBehaviour
{
    [SerializeField]
    private float ChapterTitleSpeed = 3.0f;

    [SerializeField]
    private GameObject ChapterTitle;

    [SerializeField]
    private GameObject MainText;


    public float speed = 0.01f;
    private Color textcolor;
    private Change2 change2;

    public GameObject TitleText;
    public float fadeSpeed = 0.02f;

    void Start()
    {
        textcolor = this.TitleText.GetComponent<Image>().color;
        textcolor.a = 0;
        this.TitleText.GetComponent<Image>().color = textcolor;
        change2 = GetComponent<Change2>();
    }

    private void Update()
    {
        Invoke("FadeIn", ChapterTitleSpeed);
        if (Input.GetKeyDown(KeyCode.S) || Input.GetButtonDown("Fire_2")) 
        {
            StartCoroutine(changechapter());
            Invoke(null,1f);
        }
    }

    public void Textchange()
    {
        ChapterTitle.SetActive(false);
        MainText.SetActive(true);
    }

    private IEnumerator changechapter()
    {
        ChapterTitle.SetActive(false);
        yield return new WaitUntil(() => Input.GetButtonDown("Fire_2") || Input.GetKeyDown(KeyCode.S));
        MainText.SetActive(true);
        yield return new WaitUntil(() => Input.GetButtonDown("Fire_2") || Input.GetKeyDown(KeyCode.S));
        change2.PressStart();
    }

    void FadeIn()
    {
        if(textcolor.a <= 1)
        {
            textcolor.a += fadeSpeed;
            this.TitleText.GetComponent<Image>().color = textcolor;
        }
    }
}
