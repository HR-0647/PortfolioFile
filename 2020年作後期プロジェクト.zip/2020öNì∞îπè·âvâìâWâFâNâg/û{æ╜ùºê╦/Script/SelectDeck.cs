﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectDeck : MonoBehaviour
{
    [SerializeField] GameObject cv1;
    [SerializeField] GameObject cv2;
    [SerializeField] GameObject cv3;
    [SerializeField] GameObject cv4;
    [SerializeField] GameObject Pw;
    [SerializeField] GameObject Bl;
    [SerializeField] GameObject Te;
    public void Select1()
    {
        cv1.SetActive(true);
    }

    public void NotSelect1()
    {
        cv1.SetActive(false);
    }

    public void Select2()
    {
        cv2.SetActive(true);
    }

    public void NotSelect2()
    {
        cv2.SetActive(false);
    }

    public void Select3()
    {
        cv3.SetActive(true);
    }

    public void NotSelect3()
    {
        cv3.SetActive(false);
    }

    public void WaitPlayer()
    {
        cv4.SetActive(true);
    }

    public void PwDeck()
    {
        Pw.SetActive(true);
    }

    public void BlDeck()
    {
        Bl.SetActive(true);
    }

    public void TeDeck()
    {
        Te.SetActive(true);
    }
}
