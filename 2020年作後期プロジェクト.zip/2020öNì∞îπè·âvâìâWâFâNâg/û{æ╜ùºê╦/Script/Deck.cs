﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Deck
{
    //デッキの枚数
    public int Decklength = 10;
    public List<Trap> CardList;
    private DeckData deckData;

    public Deck(DeckData deckData)
    {
        this.deckData = deckData;
        //カードリストの初期化
        CardList = new List<Trap>();

        //Debug.Log("カード生成");
        //カード生成
        for (int i = 0; i < deckData.deckid.Length; i++)
        {
            CardList.Add(new Trap(deckData.deckid[i]));
            //CardList.Add(new Card() { numbers = 1});
            //CardList.Add(new Card() { numbers = 2});
            //CardList.Add(new Card() { numbers = 3});
        }
        //カード生成時の確認
        //foreach (Card card in CardList)
        //{
        //    Debug.Log(card.numbers);
        //}

        Shuffle();
        Trap card1 = DrawCard();
        CardSort();
    }

    public void Shuffle()
    {
        //カードと罠ナンバーをシャッフルする
        //Debug.Log("シャッフルします");
        for (int i = 0; i < CardList.Count; i++)
        {
            Trap temp = CardList[i];
            int randomIndex = Random.Range(0, CardList.Count);
            CardList[i] = CardList[randomIndex];
            CardList[randomIndex] = temp;
        }
        //シャッフル時の確認
        //foreach (Card card in CardList)
        //{
        //    Debug.Log(card.numbers);
        //}
    }

    public Trap DrawCard()
    {
        //デッキからカードを一枚引く
        Trap card = CardList[0];
        CardList.RemoveAt(0);
        //Debug.Log("ドロー");
        return card;
    }

    public void CardSort()
    {
        //Debug.Log("カードをソートします");
        CardList.Sort();

        //ソートの確認
        foreach (Trap card in CardList)
        {
            //Debug.Log(card.numbers);
        }
    }
}
