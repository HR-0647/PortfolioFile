﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;
using UnityEngine.UI;

public class Scenestory3 : MonoBehaviour
{
    //インスペクターで取得
    [SerializeField, Header("- シーン遷移先名")]
    private string sceneLoadNameToTanuRoute;
    [SerializeField]
    private string sceneLoadNameToUsaRoute;
    //インスペクターで取得
    [SerializeField] private ButtonSelect buttonSelect;
    [SerializeField] private UnityEngine.UI.Text textbox; //文章
    [SerializeField] private UnityEngine.UI.Text textbox2; //名前
    [SerializeField] private SpriteRenderer body, face; //野獣の表情差分
    [SerializeField] private SpriteRenderer body2, face2; //美女の表情差分
    [SerializeField] private SpriteRenderer body3, face3; //ウサギの表情
    [SerializeField] private SpriteRenderer body4, face4; //タヌキの表情
    [SerializeField] private SpriteRenderer Emote1, Emote2;
    [SerializeField] private SpriteRenderer Emote4, Emote411, Emote422;
    [SerializeField] private SpriteAtlas atlas; //野獣の表情差分のパーツ
    [SerializeField] private SpriteAtlas atlas2; //美女の表情差分のパーツ
    [SerializeField] private SpriteAtlas atlas3;
    [SerializeField] private SpriteAtlas atlas4;
    [SerializeField] private GameObject SelectButton;
    [SerializeField] private GameObject SelectButton2;
    [SerializeField] private SpriteAtlas Emote; //エモートアイコン
    [SerializeField] private SpriteAtlas Emote41;
    [SerializeField] private SpriteAtlas Emote42;
    [SerializeField] private GameObject FlashImage;
    [SerializeField] private AudioSource SinarioSE;
    //[SerializeFieldprivate ] SpriteAtlas Emote122;
    //[SerializeField] SpriteAtlas Emote133;
    [SerializeField]
    [Range(0.001f, 0.3f)]
    float intervalForCharacterDisplay = 0.05f; //1文字にかかる時間
    [SerializeField]
    [Range(0.001f, 0.3f)]
    float intervalForCharacterDisplay2 = 0.05f; //1文字にかかる時間
    [SerializeField]
    private GameObject PressButton;

    // イメージを白黒に設定
    [SerializeField] Color btnColor1 = Color.white; //カラー選択（白と書いてありますがインスペクターで変更可能）
    [SerializeField] Color btnColor2 = Color.black;
    [SerializeField] Color btnColor3 = Color.clear;
    [SerializeField] Color btnColor4 = Color.gray;
    // 立ち絵
    [SerializeField] GameObject image;
    [SerializeField] GameObject image2;
    [SerializeField] GameObject image3;
    [SerializeField] GameObject image4;

    [Header("フェード")] public FadeImage fade;

    private bool firstPush = false;
    private bool goNextScene = false;
    private int currentLine = 0; //行番号
    private int currentLine2 = 0;
    private string cureentText = string.Empty; //文字列
    private string cureentText2 = string.Empty;
    private float timeUntilDisplay = 0; //表示にかかる時間
    private float timeElapsed = 1; //文字列の表示を開始した時間
    private int lastUpdateCharecter = -1; //表示中の文字数
    private float timeUntilDisplay2 = 0; //表示にかかる時間
    private float timeElapsed2 = 1; //文字列の表示を開始した時間
    private int lastUpdateCharecter2 = -1; //表示中の文字数
    public string[] scenarios; //シナリオ格納
    public string[] scenarios2;
    private bool beruSpeak = false;
    private bool adamuSpeak = false;
    private bool tanukiSpeak = false;
    private bool usagiSpeak = false;
    private bool usagiSpeak2 = false;
    private bool ButtonDestroy = false;
    private bool ButtonDestroy2 = false;
    private Animator Flashimage;
    private bool isFlash;
    private bool OneClick = true;
    private bool CorutinSelect1 = false;
    private bool Flag1 = false;

    private void AnimatorSet()
    {
        Flashimage.SetBool("FlashImage", isFlash);
    }

    private void Awake()
    {
        Flashimage = FlashImage.GetComponent<Animator>();
    }

    private void Start()
    {
        StartCoroutine(Sinario());
        StartCoroutine(Button());
    }
    private void Start2()
    {

    }

    private void Update()
    {
        if (currentLine < scenarios.Length && (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2")))
        {
            SetNextLine();
        }

        StartCoroutine(SinarioPressButton());

        //クリックから経過した時間が想定表示時間のなん%を確認し、表示文字数を出す
        int displayCharacterCount = (int)(Mathf.Clamp01((Time.time - timeElapsed) / timeUntilDisplay) * cureentText.Length);
        int displayCharacterCount2 = (int)(Mathf.Clamp01((Time.time - timeElapsed2) / timeUntilDisplay2) * cureentText2.Length);

        //表示文字数が前回の表示文字数と異なるテキストを更新する
        if (displayCharacterCount != lastUpdateCharecter)
        {
            textbox.text = cureentText.Substring(0, displayCharacterCount);
            lastUpdateCharecter = displayCharacterCount;
        }

        if (displayCharacterCount2 != lastUpdateCharecter2)
        {
            textbox.text = cureentText2.Substring(0, displayCharacterCount);
            lastUpdateCharecter2 = displayCharacterCount;
        }

        if (CorutinSelect1 == true)
        {
            StopCoroutine(Sinario());
        }


        if (ButtonDestroy)
        {
            SceneManager.LoadScene(sceneLoadNameToTanuRoute);
            GameManager.Instance.isGoRabbit = true;
        }

        else if (ButtonDestroy2)
        {
            SceneManager.LoadScene(sceneLoadNameToUsaRoute);
            GameManager.Instance.isGoRabbit = false;
        }

        if (Input.GetButtonDown("Fire_Options"))
        {
            currentLine = 17;
            textbox2.text = "ベル";
            body2.sprite = atlas2.GetSprite("頭身ベル_透過");
            face2.sprite = atlas2.GetSprite("頭身ベル_透過");
            SinarioSE.Play();
            adamuSpeak = false;
            beruSpeak = true;
            tanukiSpeak = true;
            usagiSpeak = true;
            CorutinSelect1 = true;
            selectButton();
            buttonSelect.enabled = true;
        }
    }

    //コルーチンからテキスト、話しているキャラを白黒させる、表情差分
    private IEnumerator Sinario()
    {
        SetNextLine();
        yield return null;
        currentLine = 1;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過 (1)");
        face.sprite = atlas.GetSprite("アダム_デフォルト");
        body2.sprite = atlas2.GetSprite("ベル_デフォルト");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        adamuSpeak = true;
        beruSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 2;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("ベル_デフォルト");
        face2.sprite = atlas2.GetSprite("頭身ベル_笑顔");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 3;
        textbox2.text = "謎の男";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 4;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("アダム_驚き");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 5;
        textbox2.text = "タヌ坊";
        image4.SetActive(false);
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        SinarioSE.Play();
        tanukiSpeak = false;
        adamuSpeak = true;
        beruSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 6;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_デフォルト");
        Emote2.sprite = Emote.GetSprite("？");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 7;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過");
        face.sprite = atlas.GetSprite("アダム_デフォルト");
        body2.sprite = atlas2.GetSprite("ベル_デフォルト");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        SinarioSE.Play();
        Emote2.enabled = false;
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 8;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki 　笑顔");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 9;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("ベル_ちょぴ怒り");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 10;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        Emote4.sprite = Emote.GetSprite("わらわら");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 11;
        textbox2.text = "";
        body3.sprite = atlas3.GetSprite("ウサギ３");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        Emote4.enabled = false;
        tanukiSpeak = true;
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak2 = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 12;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki 　驚き");
        face4.sprite = atlas4.GetSprite("tamuki 　驚き");
        Emote411.sprite = Emote41.GetSprite("！？");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak2 = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 13;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ３");
        face3.sprite = atlas3.GetSprite("ウサギ３");
        SinarioSE.Play();
        Emote411.enabled = false;
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 14;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        Emote422.sprite = Emote42.GetSprite("汗");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 15;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki　怒り");
        Emote422.enabled = false;
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 16;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過");
        face.sprite = atlas.GetSprite("アダム_デフォルト");
        SinarioSE.Play();
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine = 17;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        CorutinSelect1 = true;
        selectButton();
        buttonSelect.enabled = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
    }

    private IEnumerator Button()
    {
        OnClick1();
        OnClick2();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick4();
        OnClick33();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick33();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        CorutinSelect1 = true;
        //Debug.Log("Press Start!");
        //if (!firstPush)
        //{
        //    Debug.Log("Go Next Scene!");
        //    fade.StartFadeOut();
        //    firstPush = true;
        //}
        //yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        //Debug.Log("Press Start!");
        //if (!goNextScene && fade.IsFadeOutComplete())
        //{
        //    GameManager.Instance.InitSet();
        //    SceneManager.LoadScene("StartArea");
        //    goNextScene = true;
        //}
    }

    private IEnumerator Select1()
    {
        SetNextLine2();
        Flag1 = true;
        yield return null;
        currentLine2 = 0;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 1;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        adamuSpeak = true;
        beruSpeak = false;
        tanukiSpeak = false;
        usagiSpeak = true;
        //FlashImage.SetActive(true);
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 2;
        textbox2.text = "タヌ坊";
        body4.sprite = atlas4.GetSprite("tamuki");
        face4.sprite = atlas4.GetSprite("tamuki");
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        isFlash = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 3;
        textbox2.text = "";
        body4.sprite = atlas4.GetSprite("tanuki");
        face4.sprite = atlas4.GetSprite("tanuki");
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        tanukiSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 4;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 5;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 6;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 7;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 8;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 9;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 10;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        adamuSpeak = false;
        beruSpeak = true;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 11;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 12;
        textbox2.text = "アダム";
        body.sprite = atlas.GetSprite("頭身アダム_透過(1)");
        face.sprite = atlas.GetSprite("頭身アダム_デフォルト");
        adamuSpeak = true;
        beruSpeak = false;
        usagiSpeak = true;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 13;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;

        currentLine2 = 14;
        textbox2.text = "ウサ公";
        body3.sprite = atlas3.GetSprite("ウサギ 1");
        face3.sprite = atlas3.GetSprite("ウサギ 1");
        adamuSpeak = true;
        beruSpeak = true;
        usagiSpeak = false;
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
    }

    private IEnumerator Button2()
    {
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        OnClick4();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
        OnClick1();
        OnClick2();
        OnClick3();
        yield return new WaitUntil(() => Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"));
        yield return null;
    }

    //画像を白黒変える
    private void OnClick1() // アダムを白黒にする
    {
        if (beruSpeak == true)
        {
            body.color = btnColor2;
            face.color = btnColor2;
        }
        else if (beruSpeak == false)
        {
            body.color = btnColor1;
            face.color = btnColor1;
        }
    }

    private void OnClick2() // ベルを白黒にする
    {
        if (adamuSpeak == true)
        {
            body2.color = btnColor2;
            face2.color = btnColor2;
        }
        else if (adamuSpeak == false)
        {
            body2.color = btnColor1;
            face2.color = btnColor1;
        }
    }

    private void OnClick3()
    {
        if (usagiSpeak == true)
        {
            body3.color = btnColor2;
            face3.color = btnColor2;
        }
        else if (usagiSpeak == false)
        {
            body3.color = btnColor1;
            face3.color = btnColor1;
        }
    }

    private void OnClick33()
    {
        if (usagiSpeak2 == true)
        {
            body3.color = btnColor3;
            face3.color = btnColor3;
        }
        else if (usagiSpeak2 == false)
        {
            body3.color = btnColor4;
            face3.color = btnColor4;
        }
    }

    private void OnClick4()
    {
        if (tanukiSpeak == true)
        {
            body4.color = btnColor2;
            face4.color = btnColor2;
        }
        else if (tanukiSpeak == false)
        {
            body4.color = btnColor1;
            face4.color = btnColor1;
        }
    }

    private void selectButton()
    {
        SelectButton.SetActive(true);
        SelectButton2.SetActive(true);
    }

    public void DestroyButton()
    {
        ButtonDestroy = true;
        ButtonDestroy2 = false;
        if (ButtonDestroy == true)
        {
            SelectButton.SetActive(false);
            //Destroy(SelectButton);
        }
    }

    public void DestroyButton2()
    {
        ButtonDestroy = false;
        ButtonDestroy2 = true;
        if (ButtonDestroy == true)
        {
            SelectButton2.SetActive(false);
            //Destroy(SelectButton);
        }
    }

    void SetNextLine()
    {
        cureentText = scenarios[currentLine];
        currentLine++;

        //想定表示時間と現在の時刻をキャッシュ
        timeUntilDisplay = cureentText.Length * intervalForCharacterDisplay;
        timeElapsed = Time.time;

        //文字カウントを初期化
        lastUpdateCharecter = -1;
    }

    void SetNextLine2()
    {
        cureentText2 = scenarios2[currentLine2];
        currentLine2++;

        //想定表示時間と現在の時刻をキャッシュ
        timeUntilDisplay2 = cureentText2.Length * intervalForCharacterDisplay2;
        timeElapsed2 = Time.time;

        //文字カウントを初期化
        lastUpdateCharecter2 = -1;
    }

    public void SkipScene()
    {
        currentLine = 17;
        textbox2.text = "ベル";
        body2.sprite = atlas2.GetSprite("頭身ベル_透過");
        face2.sprite = atlas2.GetSprite("頭身ベル_透過");
        SinarioSE.Play();
        adamuSpeak = false;
        beruSpeak = true;
        tanukiSpeak = true;
        usagiSpeak = true;
        CorutinSelect1 = true;
        selectButton();
        buttonSelect.enabled = true;
    }

    public IEnumerator SinarioPressButton()
    {
        if (Input.GetKeyUp("s") || Input.GetButtonDown("Fire_2"))
        {
            yield return new WaitForSeconds(intervalForCharacterDisplay);
            PressButton.SetActive(false);
            yield return new WaitForSeconds(timeUntilDisplay);
            PressButton.SetActive(true);
        }
    }
}
