﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IlllusionDestroy : MonoBehaviour
{
    public float IllusionDTime;
    public float TimeLiIl;

    private void Start()
    {
        TimeLiIl = IllusionDTime;
        gameObject.SetActive(true);
    }

    private void OnEnable()
    {
        TimeLiIl = IllusionDTime;
        gameObject.SetActive(true);
    }

    private void OnDisable()
    {
        TimeLiIl -= Time.deltaTime;

        if (TimeLiIl <= 0)
        {
            gameObject.SetActive(false);
        }
        OnEnable();
    }
}
