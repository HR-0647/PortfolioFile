﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Card : IComparable
{
    public int numbers;

    public Card(int numbers)
    {
        this.numbers = numbers;
    }

    public Card()
    {
        
    }

    public int CompareTo(object obj)
    {
        Card C = obj as Card;

        if (numbers <= 30)
        {
            return C.numbers.CompareTo(numbers);
        }
        else
        {
            throw new ArgumentException();
        }
    }
}
