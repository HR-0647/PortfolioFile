﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zangeki : MonoBehaviour
{
    [SerializeField]
    public PolygonCollider2D pcol;
    [SerializeField]
    public GameObject Enemy;

    [SerializeField, Header("- ソードの斬撃による攻撃")]
    public int Swordslash = 30;
    [SerializeField, Header("- ソードヒット時にどれだけMP回復するか")]
    private int hitHealMp;
    [SerializeField]
    private AudioSource ZANGEKIse;
    [SerializeField]
    private AudioSource HitSE;

    // Start is called before the first frame update
    void Start()
    {
        hitHealMp = 5;
    }

    private void OnTriggerEnter2D(Collider2D cllision)
    {

        //Debug.Log(cllision.name);
        //if (cllision.gameObject.name == "Enemy")
        //{
        //    cllision.gameObject.transform.GetComponent<Enemy>().DownHp(normalSwordAttakPoint);
        //}
        if (cllision.gameObject.CompareTag("Enemy"))
        {
            //ZANGEKIse.Play();
            GameManager.Instance.girlCurrentMp += hitHealMp;
            //GameManager.Instance.beastCurrentMp += hitHealMp;
            cllision.gameObject.transform.GetComponent<Enemy>().DownHp(Swordslash);
            HitSE.Play();
        }
    }

    // Update is called once per frame
    void Update()
    {
        Destroy(this.gameObject, 0.5f);
    }
}